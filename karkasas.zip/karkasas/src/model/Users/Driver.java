package model.Users;

import lombok.*;
import model.Transport.Destination;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Driver extends User implements Serializable {

    private String driversLicenceId;

    @OneToMany(mappedBy = "driver", cascade = CascadeType.ALL)
    private List<Destination> destinationList;
    public Driver(String name, String surname, String username, String password, String email, String phoneNumber, String address, LocalDate birthDate, String driversLicenceId) {
        super(name, surname, username, password, email, phoneNumber, address, birthDate);
        this.driversLicenceId = driversLicenceId;
    }

    public String getDriversLicenceId() {
        return driversLicenceId;
    }

    public void setDriversLicenceId(String driversLicenceId) {
        this.driversLicenceId = driversLicenceId;
    }
}
