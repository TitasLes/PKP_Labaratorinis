package model.Users;

import lombok.*;

import javax.persistence.Entity;
import java.io.Serializable;
import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Manager extends User implements Serializable {

    private String workEmail;

    public Manager(String name, String surname, String username, String password, String email, String phoneNumber, String address, LocalDate birthDate, String workEmail) {
        super(name, surname, username, password, email, phoneNumber, address, birthDate);
        this.workEmail = workEmail;
    }

    public String ToString(){
        return getName() + " " + getSurname() + " " + getEmail();
    }

    public String getWorkEmail() {
        return workEmail;
    }

    public void setWorkEmail(String workEmail) {
        this.workEmail = workEmail;
    }
}
