package model.Transport;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

@Data
@Entity
@NoArgsConstructor
public class Vehicle implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String name;
    private String model;
    private String description;
    private int horsePower;
    private float fuelConsumptionIn100Km;


    @OneToMany(mappedBy = "vehicle", cascade =CascadeType.ALL, orphanRemoval = true)
    private List<Destination> vehiclesInDestinations;

    public Vehicle(String name, String model, String description, String horsePower, String fuelConsumptionIn100Km) {
        this.name = name;
        this.model = model;
        this.description = description;

        this.horsePower = Integer.parseInt(horsePower);
        this.fuelConsumptionIn100Km = Float.parseFloat(fuelConsumptionIn100Km);
    }

    @Override
    public String toString(){
        return name + " " + model;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getHorsePower() {
        return String.valueOf(horsePower);

    }

    public void setHorsePower(String horsePower){
        this.horsePower = Integer.parseInt(horsePower);
    }

    public String getFuelConsumptionIn100Km() {
        return String.valueOf(fuelConsumptionIn100Km);
    }

    public void setFuelConsumptionIn100Km(String fuelConsumptionIn100Km) {
        this.fuelConsumptionIn100Km = Float.parseFloat(fuelConsumptionIn100Km);
    }

    public List<Destination> getVehiclesInDestinations() {
        return vehiclesInDestinations;
    }

    public void setVehiclesInDestinations(List<Destination> vehiclesInDestinations) {
        this.vehiclesInDestinations = vehiclesInDestinations;
    }
}
