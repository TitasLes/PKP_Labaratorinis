package model.Transport;

import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Cargo implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String content;
    @OneToOne (cascade = CascadeType.ALL)
    private Destination destination;

    private LocalDate leaveDate;
    private LocalDate expectedArrivalDate;
    private LocalDate ArrivalDate;
    private CargoStatus status;

    public Cargo(String content, Destination destination) {
        this.content = content;
        this.destination = destination;
    }

    @Override
    public String toString(){
        return content + " - (" + destination +")";
    }

    public String toGraphString(){
        return content;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Destination getDestination() {
        return destination;
    }

    public void setDestination(Destination destination) {
        this.destination = destination;
    }

    public LocalDate getLeaveDate() {
        return leaveDate;
    }

    public void setLeaveDate(LocalDate leaveDate) {
        this.leaveDate = leaveDate;
    }

    public LocalDate getExpectedArrivalDate() {
        return expectedArrivalDate;
    }

    public void setExpectedArrivalDate(LocalDate expectedArrivalDate) {
        this.expectedArrivalDate = expectedArrivalDate;
    }

    public LocalDate getArrivalDate() {
        return ArrivalDate;
    }

    public void setArrivalDate(LocalDate arrivalDate) {
        ArrivalDate = arrivalDate;
    }

    public CargoStatus getStatus() {
        return status;
    }

    public void setStatus(CargoStatus status) {
        this.status = status;
    }

    public String getName() {
        return content;
    }

    /*
    public Destination getDestination() {
        return destination;
    }

    public String getDestinationSting() {
        return String.valueOf(Destination);
    }

    public void setDestination(Destination destination) {
        this.destination = destination;
    }
*/
}
