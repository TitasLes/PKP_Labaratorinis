package hibernate;

import model.Forum.Comment;
import model.Transport.Destination;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.List;

public class CommentHib {
    EntityManager entityManager = null;
    EntityManagerFactory entityManagerFactory = null;

    public CommentHib(EntityManagerFactory entityManagerFactory) {
        this.entityManagerFactory = entityManagerFactory;
    }

    public void createComment(Comment comment) {
        entityManager = entityManagerFactory.createEntityManager();
        try {
            entityManager.getTransaction().begin();
            entityManager.persist(comment);
            entityManager.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (entityManager != null) entityManager.close();
        }
    }

    public void updateComment(Comment comment) {
        entityManager = entityManagerFactory.createEntityManager();
        try {
            entityManager.getTransaction().begin();
            entityManager.merge(comment);
            entityManager.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (entityManager != null) entityManager.close();
        }
    }

    public Comment getAllComment() {
        entityManager = entityManagerFactory.createEntityManager();
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Comment> query = criteriaBuilder.createQuery(Comment.class);
        Root<Comment> root = query.from(Comment.class);
        query.select(root);
        Query q;
        try {
            q = entityManager.createQuery(query);
            return (Comment) q.getResultList();
        } catch (NoResultException e) {
            return null;
        }

    }
    public void deleteComment(Comment comment) {
        entityManager = entityManagerFactory.createEntityManager();
        try {
            entityManager.getTransaction().begin();
            entityManager.remove(entityManager.find(Comment.class, comment.getId()));
            entityManager.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (entityManager != null) entityManager.close();
        }
    }

    public Comment getCommentById(int id) {
        entityManager = entityManagerFactory.createEntityManager();
        Comment comment = null;
        try {
            entityManager.getTransaction().begin();
            comment = entityManager.find(Comment.class, id);
            entityManager.getTransaction().commit();
        } catch (Exception e) {
            System.out.println("No such comment by given id");
        }
        return comment;
    }

    public List<Comment> getAllCommentsForForumID(int Forum_ID) {
        entityManager = entityManagerFactory.createEntityManager();
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Comment> query = criteriaBuilder.createQuery(Comment.class);

        Root<Comment> root = query.from(Comment.class);
        Predicate forum_id = criteriaBuilder.equal(root.get("forum"), Forum_ID);
        query.where(forum_id);

        query.select(root);
        Query q;
        try {
            q = entityManager.createQuery(query);
            return q.getResultList();
        } catch (NoResultException e) {
            return null;
        }

    }
}
