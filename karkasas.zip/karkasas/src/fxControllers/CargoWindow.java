
package fxControllers;

import hibernate.CargoHib;
import hibernate.DestinationHib;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import model.Transport.Cargo;
import model.Transport.Destination;
import utils.FxUtils;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class CargoWindow implements Initializable {
    @FXML
    public TextField Cname;
    @FXML
    public ChoiceBox<Destination> cargoDestination;
    @FXML
    public Button actionButton;
    @FXML
    public DatePicker CleaveDate;
    @FXML
    public DatePicker CarrivalDate;
    @FXML
    public DatePicker CexpectedDate;


    public Label TextLeave;
    public Label TextArrival;
    public Label TextExpected;
    public Label TextCargo;
    public AnchorPane Apatine;

    private Cargo currentCargo;

    private EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("CargoSystem");
    private CargoHib cargoHib = new CargoHib(entityManagerFactory);
    private DestinationHib destinationHib = new DestinationHib(entityManagerFactory);

    public void setData(EntityManagerFactory entityManagerFactory, Cargo currentCargo) {
        this.currentCargo = currentCargo;
        this.entityManagerFactory = entityManagerFactory;

        fillFields();
    }

    public void fillDestinations(){
        List arr = destinationHib.getAllDestination();
        cargoDestination.getItems().addAll(arr);


    }

    public void disableCreateFields(){
        CleaveDate.setDisable(true);
        CarrivalDate.setDisable(true);
        CexpectedDate.setDisable(true);

    }

    public void DisableData(int Propertie){
        switch(Propertie){
            case 1:{

                break;

            }
            case 2:{

                break;

            }
            case 3:{
                CleaveDate.setDisable(true);
                CarrivalDate.setDisable(true);
                CexpectedDate.setDisable(true);
                cargoDestination.setDisable(true);
                Cname.setDisable(true);
                break;
            }
            default:{}
        }
    }

    private void fillFields() {
        Cargo cargo = cargoHib.getCargoById(currentCargo.getId());
        Cname.setText(cargo.getContent());
        cargoDestination.setValue(destinationHib.getDestinationById(currentCargo.getDestination().getId()));
        CleaveDate.setValue(cargo.getLeaveDate());
        CarrivalDate.setValue(cargo.getArrivalDate());
        CexpectedDate.setValue(cargo.getExpectedArrivalDate());


        actionButton.setOnAction(actionEvent ->{
            updateCargo(cargo);
        });
        actionButton.setText("Update");

    }

    private void updateCargo (Cargo cargo) {
        cargo.setContent(Cname.getText());
        cargo.setDestination(cargoDestination.getSelectionModel().getSelectedItem());
        cargo.setLeaveDate(CleaveDate.getValue());
        cargo.setArrivalDate(CarrivalDate.getValue());
        cargo.setExpectedArrivalDate(CexpectedDate.getValue());
        try {
            cargo.setStatus(CargoStatus.valueOf(Cstatus.getSelectionModel().getSelectedItem().toString()));
        }
        catch (NullPointerException e){
            // Do nothing
        }
        cargoHib.updateCargo(cargo);
        FxUtils.alterMessage(Alert.AlertType.INFORMATION, "Successful", "Cargo creation report", "Cargo " + Cname.getText() + " updated successfully");
    }

    public void setData(EntityManagerFactory entityManagerFactory) {
        this.entityManagerFactory = entityManagerFactory;
        this.cargoHib = new CargoHib(entityManagerFactory);
    }

    public void createCargo() {
        //Checks if text fields are empty
        if(Cname.getText().isEmpty() || cargoDestination.getSelectionModel().isEmpty())
        {
            FxUtils.alterMessage(Alert.AlertType.ERROR, "Error", "Cargo creation report", "Some fields are empty");
        }
        else {
            Cargo cargo = new Cargo(Cname.getText(), cargoDestination.getSelectionModel().getSelectedItem());
            cargoHib.createCargo(cargo);

            FxUtils.alterMessage(Alert.AlertType.INFORMATION, "Successful", "Cargo creation report", "Cargo " + Cname.getText() + " created successfully");
        }

    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }
}


