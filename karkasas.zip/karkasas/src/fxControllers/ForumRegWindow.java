
package fxControllers;

import hibernate.ForumHib;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import model.Forum.Forum;
import utils.FxUtils;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.net.URL;
import java.util.ResourceBundle;

public class ForumRegWindow implements Initializable {
    @FXML
    public TextField ForumTitle;
    @FXML
    public TextField ForumDescription;
    @FXML
    public Button actionButton;

    private Forum currentForum;

    private EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("CargoSystem");
    private ForumHib forumHib = new ForumHib(entityManagerFactory);


    public void setData(EntityManagerFactory entityManagerFactory, Forum currentForum) {
        this.currentForum = currentForum;
        this.entityManagerFactory = entityManagerFactory;

        fillFields();
    }

    public void setData(EntityManagerFactory entityManagerFactory) {
        this.entityManagerFactory = entityManagerFactory;
    }

    void fillFields() {
        Forum forum = forumHib.getForumById(currentForum.getId());

        ForumTitle.setText(forum.getTitle());
        ForumDescription.setText(forum.getDescription());

        actionButton.setOnAction(actionEvent ->{
            updateForum(forum);
        });
        actionButton.setText("Update");

    }


    private void updateForum (Forum forum) {
        forum.setTitle(ForumTitle.getText());
        forum.setDescription(ForumDescription.getText());

        forumHib.updateForum(forum);
        FxUtils.alterMessage(Alert.AlertType.INFORMATION, "Successful", "Forum creation report", "Forum updated successfully");
    }


    public void createCargo() {
        //Checks if text fields are empty
        if(ForumTitle.getText().isEmpty() || ForumDescription.getText().isEmpty())
        {
            FxUtils.alterMessage(Alert.AlertType.ERROR, "Error", "Forum creation report", "Some fields are empty");
        }
        else {
            Forum forum = new Forum(ForumTitle.getText(), ForumDescription.getText());
            forumHib.createForum(forum);

            FxUtils.alterMessage(Alert.AlertType.INFORMATION, "Successful", "Forum creation report", "Forum created successfully");
        }

    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }
}


