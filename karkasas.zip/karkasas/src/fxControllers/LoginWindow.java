package fxControllers;

import hibernate.UserHib;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.Users.User;
import utils.FxUtils;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.io.IOException;

@Getter
@Setter
public class LoginWindow {
    @FXML
    public TextField usernameField;
    @FXML
    public PasswordField passwordField;

    EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("CargoSystem");
    UserHib userHib = new UserHib(entityManagerFactory);

    public void openRegistrationWindow() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(LoginWindow.class.getResource("../view/registration-window.fxml"));

        Scene scene = new Scene(fxmlLoader.load());
        //Stage stage = (Stage) usernameField.getScene().getWindow();
        Stage stage = new Stage();
        stage.initModality(Modality.WINDOW_MODAL);
        stage.initOwner(usernameField.getScene().getWindow());
        stage.setTitle("Registration!");
        stage.setScene(scene);
        stage.show();
    }

    public void openMainWindow() throws IOException {
        User user = userHib.getUserByLoginData(usernameField.getText(), passwordField.getText());
        if (user != null){
            FXMLLoader fxmlLoader = new FXMLLoader(LoginWindow.class.getResource("../view/main-window.fxml"));
            Parent parent = fxmlLoader.load();
            MainWindow mainWindow = fxmlLoader.getController();
            mainWindow.setData(entityManagerFactory, user);

            Scene scene = new Scene(parent);
            Stage stage = (Stage) usernameField.getScene().getWindow();
            stage.setTitle("Hello!");
            stage.setScene(scene);
            stage.show();
        } else{
            FxUtils.alterMessage(Alert.AlertType.INFORMATION, "Information", "User login report", "Nu such user or wrong credentials");
        }
    }
}
