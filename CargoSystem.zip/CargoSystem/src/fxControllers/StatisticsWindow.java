
package fxControllers;

import hibernate.CargoHib;
import hibernate.DestinationHib;
import hibernate.UserHib;
import hibernate.VehicleHib;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.PieChart;
import javafx.scene.control.*;
import javafx.scene.input.InputMethodEvent;
import javafx.scene.layout.AnchorPane;
import model.Statuses.CargoStatus;
import model.Statuses.Filters;
import model.Transport.Cargo;
import model.Transport.Destination;
import model.Users.Driver;
import utils.FxUtils;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Table;
import java.net.URL;
import java.util.Arrays;
import java.util.List;
import java.util.ResourceBundle;

public class StatisticsWindow implements Initializable {
    @FXML
    public ListView Lentele;
    @FXML
    public PieChart skrituliukas;
    @FXML
    public ComboBox FilterbyCombo;


    private Cargo currentCargo;
    private Driver driver;

    private EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("CargoSystem");
    private CargoHib cargoHib = new CargoHib(entityManagerFactory);
    private DestinationHib destinationHib = new DestinationHib(entityManagerFactory);
    private UserHib userHib = new UserHib(entityManagerFactory);
    private VehicleHib vehicleHib = new VehicleHib(entityManagerFactory);
    //Global list filtered Drivers by id
    private List<Destination> DestinationsByDriver;

    public void setDriver(EntityManagerFactory entityManagerFactory, Driver driver) {
        this.driver = driver;
        this.entityManagerFactory = entityManagerFactory;
        this.DestinationsByDriver = destinationHib.getAllDestinationByDriver(driver.getId());
        //fillFields();
    }

    public void setData(EntityManagerFactory entityManagerFactory) {
        this.entityManagerFactory = entityManagerFactory;
        this.cargoHib = new CargoHib(entityManagerFactory);
    };


    public void fillFields() {

        Lentele.getItems().addAll(DestinationsByDriver);

        List Filters = Arrays.asList(model.Statuses.Filters.values());
        FilterbyCombo.getItems().addAll(Filters);

        DrawChart();

    }

    @FXML
    private void DrawChart(){
        ObservableList<PieChart.Data> pieChartData = FXCollections.observableArrayList();
        switch (FilterbyCombo.getSelectionModel().getSelectedIndex()){
            case 0:{
                for (int i=0; i<DestinationsByDriver.size(); i++)
                {
                    pieChartData.add(new PieChart.Data(DestinationsByDriver.get(i).getStartPoint(), 1));
                }
                skrituliukas.setTitle("Startpoint data in trips");
                break;

            }
            case 1:{
                for (int i=0; i<DestinationsByDriver.size(); i++)
                {
                    pieChartData.add(new PieChart.Data(DestinationsByDriver.get(i).getEndPoint(), 1));
                }
                skrituliukas.setTitle("EndPoint data in trips");
                break;

            }
            case 2:{
                for (int i=0; i<DestinationsByDriver.size(); i++)
                {
                    pieChartData.add(new PieChart.Data(DestinationsByDriver.get(i).getCargo().toGraphString(), 1));
                }
                skrituliukas.setTitle("Cargo data in trips");
                break;

            }
            case 3:{
                for (int i=0; i<DestinationsByDriver.size(); i++)
                {
                    pieChartData.add(new PieChart.Data(DestinationsByDriver.get(i).getManager().toString(), 1));
                }
                skrituliukas.setTitle("Manager data in trips");
                break;
            }
            case 4:
            default:{
                for (int i=0; i<DestinationsByDriver.size(); i++)
                {
                    pieChartData.add(new PieChart.Data(DestinationsByDriver.get(i).getVehicle().toString(), 1));
                }
                skrituliukas.setTitle("Vehicle data in trips");
                break;
            }
        }

        skrituliukas.setData(pieChartData);
    }


    @Override
    public void initialize(URL location, ResourceBundle resources) {



    }
}


