package fxControllers;

import hibernate.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.Forum.Forum;
import model.Statuses.CargoStatus;
import model.Transport.Cargo;
import model.Transport.Destination;
import model.Transport.Vehicle;
import model.Users.Admin;
import model.Users.Driver;
import model.Users.Manager;
import model.Users.User;
import utils.FxUtils;

import javax.persistence.EntityManagerFactory;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class MainWindow implements Initializable {
    public Tab userManagementTab;
    public TabPane allTabs;
    @FXML
    public ListView<Driver> driversList;
    @FXML
    public ListView<Manager> managersList;
    @FXML
    public ListView<Vehicle> vehicleList;
    @FXML
    public ListView<Cargo> cargoList;
    @FXML
    public ListView<Destination> destinationList;
    @FXML
    public ListView<Forum> ForumList;

    public Button CreateDestinationButton;
    public Button CreateCargoButton;
    public Button CreateVehicleButton;
    public Button DeleteVehicleButton;
    public Button DestinationDeleteButton;
    public Button CargoDeleteButton;

    private EntityManagerFactory entityManagerFactory;

    public Admin admin;
    public Driver driver;
    public Manager manager;
    public int Role;

    private UserHib userHib;
    public User user;

    private VehicleHib vehicleHib;
    private Vehicle vehicle;

    private CargoHib cargoHib;
    private Cargo cargo;

    private DestinationHib destinationHib;
    private Destination destination;



    private ForumHib forumHib;
    private Forum forum;

    public void setData(EntityManagerFactory entityManagerFactory, User user) {
        this.entityManagerFactory = entityManagerFactory;
        this.userHib = new UserHib(entityManagerFactory);
        this.user = user; //<<- čia ateina iš login puslapio objektas User ir jis priskiriamas naujam langui MainWindow

        try {
            this.admin = (Admin) user;
            Role = 1;
        } catch (Exception e) {
            //e.printStackTrace();
        }
        try{
            this.manager = (Manager) user;
            Role = 2;
        }catch (Exception e) {
            //e.printStackTrace();
        }
        try{
            this.driver = (Driver) user;
            Role = 3;
        }catch (Exception e) {
            //e.printStackTrace();
        }

        this.vehicleHib = new VehicleHib(entityManagerFactory);
        this.destinationHib = new DestinationHib(entityManagerFactory);
        this.cargoHib = new CargoHib(entityManagerFactory);
        this.forumHib = new ForumHib(entityManagerFactory);

        fillAllLists();
        disableData();
    }

    //Trina TAB jog kiti useriai nematytu
    private void disableData() {
        try {
            if (!(admin == null)) {

            }
            if (!(manager == null)){
                allTabs.getTabs().remove(userManagementTab);

            }
            if (!(driver == null)){
                allTabs.getTabs().remove(userManagementTab);
                CreateDestinationButton.setDisable(true);
                CreateCargoButton.setDisable(true);
                CreateVehicleButton.setDisable(true);

                DeleteVehicleButton.setDisable(true);
                DestinationDeleteButton.setDisable(true);
                CargoDeleteButton.setDisable(true);
            }

        } catch (Exception e) {
            e.printStackTrace();
            //allTabs.getTabs().remove(userManagementTab);
        }
    }

    private void fillAllLists() {
        List<Driver> allDrivers = userHib.getAllDrivers();
        allDrivers.forEach(u -> driversList.getItems().add(u));

        List<Manager> allManagers = userHib.getAllManagers();
        allManagers.forEach(m -> managersList.getItems().add(m));

        List<Vehicle> allVehicles = vehicleHib.getAllVehicle();
        allVehicles.forEach(v -> vehicleList.getItems().add(v));

        if(!(driver == null)){
            List<Destination> DriverDestinations = destinationHib.getAllDestinationByDriver(driver.getId());
            DriverDestinations.forEach(d -> destinationList.getItems().add(d));
        }
        else {
            List<Destination> allDestinations = destinationHib.getAllDestination();
            allDestinations.forEach(d -> destinationList.getItems().add(d));
        }

        if(!(driver == null)){
            List<Destination> DriverDestinations = destinationHib.getAllDestinationByDriver(driver.getId());
            List<Cargo> allCargo = cargoHib.getAllCargo();

            List<Cargo> FilteredCargo = new ArrayList<Cargo>();
            for(int i=0; i<allCargo.size(); i++){

                for (int y=0; y<DriverDestinations.size(); y++){
                    String a = allCargo.get(i).getDestination().toString();
                    String b = DriverDestinations.get(y).toString();
                    if (a.equals(b)){
                        FilteredCargo.add(allCargo.get(i));
                    }
                }
            }
            FilteredCargo.forEach(c -> cargoList.getItems().add(c));

        }
        else{
            List<Cargo> allCargo = cargoHib.getAllCargo();
            allCargo.forEach(c -> cargoList.getItems().add(c));
        }



        List<Forum> allForums = forumHib.getAllForum();
        allForums.forEach(f -> ForumList.getItems().add(f));
    }

    public void refreshList() {
        driversList.getItems().clear();
        managersList.getItems().clear();
        vehicleList.getItems().clear();
        destinationList.getItems().clear();
        cargoList.getItems().clear();
        ForumList.getItems().clear();
        fillAllLists();
    }

    public void setUser(User user) {
        this.user = user;
    }

    // USERS FUN

    public void createUser() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(LoginWindow.class.getResource("../view/registration-window.fxml"));
        Parent parent = fxmlLoader.load();
        RegistrationWindow registrationWindow = fxmlLoader.getController();
        registrationWindow.setData(entityManagerFactory);

        Scene scene = new Scene(parent);
        Stage stage = new Stage();

        stage.setTitle("Hello!");
        stage.setScene(scene);
        stage.showAndWait();
    }

    public void updateUser() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(LoginWindow.class.getResource("../view/registration-window.fxml"));
        Parent parent = fxmlLoader.load();
        RegistrationWindow registrationWindow = fxmlLoader.getController();
        if (driversList.getSelectionModel().getSelectedItem() != null) {
            registrationWindow.setData(entityManagerFactory, user, driversList.getSelectionModel().getSelectedItem());

            Scene scene = new Scene(parent);
            Stage stage = new Stage();

            stage.initOwner((Stage) driversList.getScene().getWindow());
            stage.initModality(Modality.WINDOW_MODAL);
            stage.setTitle("Hello!");
            stage.setScene(scene);
            stage.showAndWait();
        }
        if (managersList.getSelectionModel().getSelectedItem() != null) {
            System.out.println("CAME");
            registrationWindow.setData(entityManagerFactory, user, managersList.getSelectionModel().getSelectedItem());

            Scene scene = new Scene(parent);
            Stage stage = new Stage();

            stage.initOwner((Stage) managersList.getScene().getWindow());
            stage.initModality(Modality.WINDOW_MODAL);
            stage.setTitle("Hello!");
            stage.setScene(scene);
            stage.showAndWait();
        }
    }

    public void deleteUser() {

        //Driver drivertest1 = driversList.getSelectionModel().getSelectedItem();
        //Manager mangertest1 = managersList.getSelectionModel().getSelectedItem();

        if (driversList.getSelectionModel().getSelectedItem() != null) {
            userHib.deleteUser((Driver) driversList.getSelectionModel().getSelectedItem());
            driversList.getItems().remove(driversList.getSelectionModel().getSelectedItem());
            driversList.getSelectionModel().clearSelection();
        }

        if (managersList.getSelectionModel().getSelectedItem() != null) {
            userHib.deleteUser((Manager) managersList.getSelectionModel().getSelectedItem());
            managersList.getItems().remove(managersList.getSelectionModel().getSelectedItem());
            managersList.getSelectionModel().clearSelection();
        }
    }

    // VEHICLE FUN

    public void createVehicle() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(LoginWindow.class.getResource("../view/Vehicle-window.fxml"));
        Parent parent = fxmlLoader.load();
        VehicleWindow vehicleWindow = fxmlLoader.getController();

        Scene scene = new Scene(parent);
        Stage stage = new Stage();

        stage.initModality(Modality.WINDOW_MODAL);
        stage.setTitle("Vehicle Form!");
        stage.setScene(scene);
        stage.show();
    }

    public void updateVehicle() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(LoginWindow.class.getResource("../view/Vehicle-window.fxml"));
        Parent parent = fxmlLoader.load();
        VehicleWindow vehicleWindow = fxmlLoader.getController();
        vehicleWindow.setData(entityManagerFactory, vehicleList.getSelectionModel().getSelectedItem());
        vehicleWindow.DisableData(Role);

        Scene scene = new Scene(parent);
        Stage stage = new Stage();

        stage.initModality(Modality.WINDOW_MODAL);
        stage.setTitle("Vehicle Form!");
        stage.setScene(scene);
        stage.show();

    }

    public void deleteVehicle() {
        /* Vehicle vehicle1 = vehicleList.getSelectionModel().getSelectedItem(); // Testuojamas objektas koks ateina. */
        vehicleHib.deleteVehicle((Vehicle) vehicleList.getSelectionModel().getSelectedItem());
        vehicleList.getItems().remove(vehicleList.getSelectionModel().getSelectedItem());
        vehicleList.getSelectionModel().clearSelection();

    }

    // CARGO FUN

    public void createCargo() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(LoginWindow.class.getResource("../view/cargo-window.fxml"));
        Parent parent = fxmlLoader.load();
        CargoWindow cargoWindow = fxmlLoader.getController();
        cargoWindow.setData(entityManagerFactory);
        cargoWindow.fillDestinations();
        cargoWindow.disableCreateFields();

        Scene scene = new Scene(parent);
        Stage stage = new Stage();

        stage.initModality(Modality.WINDOW_MODAL);
        stage.setTitle("Cargo Form!");
        stage.setScene(scene);
        stage.show();
    }

    public void updateCargo() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(LoginWindow.class.getResource("../view/cargo-window.fxml"));
        Parent parent = fxmlLoader.load();
        CargoWindow cargoWindow = fxmlLoader.getController();
        cargoWindow.fillDestinations();
        cargoWindow.DisableData(Role);
        cargoWindow.setData(entityManagerFactory, cargoList.getSelectionModel().getSelectedItem());

        Scene scene = new Scene(parent);
        Stage stage = new Stage();

        stage.initModality(Modality.WINDOW_MODAL);
        stage.setTitle("Cargo Form!");
        stage.setScene(scene);
        stage.show();

    }

    public void deleteCargo() {
        Cargo cargo = cargoList.getSelectionModel().getSelectedItem();
        if(cargo.getStatus() == CargoStatus.NOT_STARTED)
        {
            cargoHib.deleteCargo((Cargo) cargoList.getSelectionModel().getSelectedItem());
            cargoList.getItems().remove(cargoList.getSelectionModel().getSelectedItem());
            cargoList.getSelectionModel().clearSelection();
        }
        else FxUtils.alterMessage(Alert.AlertType.ERROR, "Error", "Cargo deletion report", "Started cargo can't be deleted");

    }

    // DESTINATION FUN

    public void createDestination() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(LoginWindow.class.getResource("../view/destination-window.fxml"));
        Parent parent = fxmlLoader.load();
        DestinationWindow destinationWindow = fxmlLoader.getController();
        destinationWindow.setManager(manager);
        destinationWindow.fillWindows();
        destinationWindow.disableCreateFields();

        Scene scene = new Scene(parent);
        Stage stage = new Stage();

        stage.initModality(Modality.WINDOW_MODAL);
        stage.setTitle("Destination Form!");
        stage.setScene(scene);
        stage.show();

    }

    public void updateDestination(ActionEvent actionEvent) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(LoginWindow.class.getResource("../view/destination-window.fxml"));
        Parent parent = fxmlLoader.load();
        DestinationWindow destinationWindow = fxmlLoader.getController();
        destinationWindow.fillWindows();
        destinationWindow.DisableData(Role);
        destinationWindow.setData(entityManagerFactory, destinationList.getSelectionModel().getSelectedItem(), manager);

        Scene scene = new Scene(parent);
        Stage stage = new Stage();

        stage.initModality(Modality.WINDOW_MODAL);
        stage.setTitle("Destination Form!");
        stage.setScene(scene);
        stage.show();

    }

    public void deleteDestination(){
        destinationHib.deleteDestination(destinationList.getSelectionModel().getSelectedItem());
        destinationList.getItems().remove(destinationList.getSelectionModel().getSelectedItem());
        destinationList.getSelectionModel().clearSelection();
    }


    //LISTENERS
    @FXML
    public void DrivenMouseExitedEvent(MouseEvent event) {
        managersList.getSelectionModel().clearSelection();
    }
    @FXML
    public void ManagerMouseExitedEvent(MouseEvent event) {
        driversList.getSelectionModel().clearSelection();
    }

    //INIT
    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }


    public void Statistics(ActionEvent actionEvent) throws IOException {
        if (driversList.getSelectionModel().getSelectedItem() != null) {
            FXMLLoader fxmlLoader = new FXMLLoader(LoginWindow.class.getResource("../view/Statistics-window.fxml"));
            Parent parent = fxmlLoader.load();
            StatisticsWindow statisticsWindow = fxmlLoader.getController();
            statisticsWindow.setDriver(entityManagerFactory, driversList.getSelectionModel().getSelectedItem());
            statisticsWindow.fillFields();
            //statisticsWindow.DrawChart();

            Scene scene = new Scene(parent);
            Stage stage = new Stage();

            stage.initModality(Modality.WINDOW_MODAL);
            stage.setTitle("User Statistics");
            stage.setScene(scene);
            stage.show();

        }

    }

    public void createForum(ActionEvent actionEvent) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(LoginWindow.class.getResource("../view/ForumReg-window.fxml"));
        Parent parent = fxmlLoader.load();
        ForumRegWindow forumRegWindow = fxmlLoader.getController();
        forumRegWindow.setData(entityManagerFactory);

        Scene scene = new Scene(parent);
        Stage stage = new Stage();

        stage.initModality(Modality.WINDOW_MODAL);
        stage.setTitle("ForumCreation Form!");
        stage.setScene(scene);
        stage.show();
    }

    public void updateForum(ActionEvent actionEvent) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(LoginWindow.class.getResource("../view/ForumReg-window.fxml"));
        Parent parent = fxmlLoader.load();
        ForumRegWindow forumRegWindow = fxmlLoader.getController();
        forumRegWindow.setData(entityManagerFactory, ForumList.getSelectionModel().getSelectedItem());
        forumRegWindow.fillFields();


        Scene scene = new Scene(parent);
        Stage stage = new Stage();

        stage.initModality(Modality.WINDOW_MODAL);
        stage.setTitle("ForumCreation Form!");
        stage.setScene(scene);
        stage.show();
    }

    public void deleteForum(ActionEvent actionEvent) {
    }

    public void GoToForum() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(LoginWindow.class.getResource("../view/Comments-window.fxml"));
        Parent parent = fxmlLoader.load();
        CommentsWindow commentsWindow = fxmlLoader.getController();
        commentsWindow.setData(entityManagerFactory, user, ForumList.getSelectionModel().getSelectedItem());

        Scene scene = new Scene(parent);
        Stage stage = new Stage();

        stage.initModality(Modality.WINDOW_MODAL);
        stage.setTitle("Comment Form!");
        stage.setScene(scene);
        stage.show();
    }
}