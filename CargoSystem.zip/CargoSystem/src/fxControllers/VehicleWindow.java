package fxControllers;

import hibernate.UserHib;
import hibernate.VehicleHib;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import model.Users.Driver;
import model.Users.Manager;
import model.Users.User;
import model.Transport.Vehicle;
import utils.FxUtils;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.net.URL;
import java.util.ResourceBundle;

public class VehicleWindow implements Initializable {
    @FXML
    public TextField Vname;
    @FXML
    public TextField Vmodel;
    @FXML
    public TextField Vdescription;
    @FXML
    public TextField Vpower;
    @FXML
    public TextField VfuelConsumption;

    @FXML
    public Button actionButton;

    private UserHib userHib;
    private Vehicle currentVehicle;

    private User currenUser;
    private Driver selectedDriver;
    private Manager selectedManager;

    private EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("CargoSystem");
    private VehicleHib vehicleHib = new VehicleHib(entityManagerFactory);

    public void setData(EntityManagerFactory entityManagerFactory, Vehicle currentVehicle) {
        this.currenUser = currenUser;
        this.entityManagerFactory = entityManagerFactory;
        this.currentVehicle = currentVehicle;
        this.vehicleHib = new VehicleHib(entityManagerFactory);

        fillFields();
    }

    public void DisableData(int Propertie){
        switch(Propertie){
            case 1:{

                break;

            }
            case 2:{

                break;
            }
            case 3:{
                break;
            }
            default:{}
        }
    }

    private void fillFields() {
        Vehicle vehicle = (Vehicle) vehicleHib.getVehicleById(currentVehicle.getId());
        Vname.setText(vehicle.getName());
        Vmodel.setText(vehicle.getModel());
        Vdescription.setText(vehicle.getDescription());
        Vpower.setText(vehicle.getHorsePower());
        VfuelConsumption.setText(vehicle.getFuelConsumptionIn100Km());

        actionButton.setOnAction(actionEvent ->{
            updateVehicle(vehicle);
        });
        actionButton.setText("Update");

    }

    private void updateVehicle(Vehicle vehicle) {
        vehicle.setName(Vname.getText());
        vehicle.setModel(Vmodel.getText());
        vehicle.setDescription(Vdescription.getText());
        vehicle.setHorsePower(Vpower.getText());
        vehicle.setFuelConsumptionIn100Km(VfuelConsumption.getText());
        vehicleHib.updateVehicle(vehicle);
        FxUtils.alterMessage(Alert.AlertType.INFORMATION, "Successful", "Vehicle creation report", "Vehicle " + Vname.getText() + " updated successfully");
    }

    public void setData(EntityManagerFactory entityManagerFactory) {
        this.entityManagerFactory = entityManagerFactory;
        this.vehicleHib = new VehicleHib(entityManagerFactory);
    }

    public void createVehicle() {
        //Checks if text fields are empty
        if(Vname.getText().isEmpty() || Vmodel.getText().isEmpty() || Vdescription.getText().isEmpty())
        {
            FxUtils.alterMessage(Alert.AlertType.ERROR, "Error", "Vehicle creation report", "Some fields are empty");
        }
        else {
            Vehicle vehicle = new Vehicle(Vname.getText(), Vmodel.getText(), Vdescription.getText(), Vpower.getText(), VfuelConsumption.getText());
            vehicleHib.createVehicle(vehicle);

            FxUtils.alterMessage(Alert.AlertType.INFORMATION, "Successful", "Vehicle creation report", "Vehicle " + Vname.getText() + " created successfully");
        }

    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }
}
