package fxControllers;

import hibernate.UserHib;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import model.Users.Driver;
import model.Users.Manager;
import model.Users.User;
import utils.FxUtils;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.net.URL;
import java.util.ResourceBundle;

public class RegistrationWindow implements Initializable {
    @FXML
    public TextField firstNameField;
    @FXML
    public TextField emailField;
    @FXML
    public PasswordField passwordField;
    @FXML
    public TextField phoneNumberField;
    @FXML
    public TextField addressField;
    @FXML
    public DatePicker birthDateField;
    @FXML
    public TextField lastNameField;
    @FXML
    public CheckBox managerChk;
    @FXML
    public TextField usernameField;
    @FXML
    public TextField workEmailField;
    @FXML
    public TextField driversLicenceId;
    @FXML
    public Button actionButton;

    //private EntityManagerFactory entityManagerFactory;
    //private UserHib userHib;
    private User currenUser;
    private Driver selectedDriver;
    private Manager selectedManager;

    private EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("CargoSystem");
    private UserHib userHib = new UserHib(entityManagerFactory);

    public void setData(EntityManagerFactory entityManagerFactory) {
        this.entityManagerFactory = entityManagerFactory;
        this.userHib=new UserHib(entityManagerFactory);
    }

    public void setData(EntityManagerFactory entityManagerFactory, User currenUser, Driver selectedDriver) {
        this.currenUser = currenUser;
        this.entityManagerFactory = entityManagerFactory;
        this.selectedDriver=selectedDriver;
        this.userHib=new UserHib(entityManagerFactory);

        fillFieldsDriver();
    }
    public void setData(EntityManagerFactory entityManagerFactory, User currenUser, Manager selectedManager) {
        this.currenUser = currenUser;
        this.entityManagerFactory = entityManagerFactory;
        this.selectedManager=selectedManager;
        this.userHib=new UserHib(entityManagerFactory);

        fillFieldsManager();
    }
    //Lango lauku fill driveriu
    private void fillFieldsDriver() {
        Driver driver = (Driver) userHib.getUserById(selectedDriver.getId());
        usernameField.setText(driver.getUsername());
        passwordField.setText(driver.getPassword());
        firstNameField.setText(driver.getName());
        lastNameField.setText(driver.getSurname());
        emailField.setText(driver.getEmail());
        phoneNumberField.setText(driver.getPhoneNumber());
        addressField.setText(driver.getAddress());
        birthDateField.setValue(driver.getBirthDate());
        driversLicenceId.setText(driver.getDriversLicenceId());
        actionButton.setOnAction(actionEvent ->{
            updateUserDriver(driver);
        });
        actionButton.setText("Update");
        isManager();
    }
    //Lango lauku fill manageriu
    private void fillFieldsManager() {
        Manager manager = (Manager) userHib.getUserById(selectedManager.getId());
        usernameField.setText(manager.getUsername());
        passwordField.setText(manager.getPassword());
        firstNameField.setText(manager.getName());
        lastNameField.setText(manager.getSurname());
        emailField.setText(manager.getEmail());
        phoneNumberField.setText(manager.getPhoneNumber());
        addressField.setText(manager.getAddress());
        birthDateField.setValue(manager.getBirthDate());
        workEmailField.setText(manager.getWorkEmail());
        managerChk.setSelected(true);
        actionButton.setOnAction(actionEvent ->{
            updateUserManager(manager);
        });
        actionButton.setText("Update");
        isManager();

    }
    //Driver updatas
    private void updateUserDriver(Driver driver) {
        driver.setUsername(usernameField.getText());
        driver.setPassword(passwordField.getText());
        driver.setName(firstNameField.getText());
        driver.setSurname(lastNameField.getText());
        driver.setEmail(emailField.getText());
        driver.setPhoneNumber(phoneNumberField.getText());
        driver.setAddress(addressField.getText());
        driver.setBirthDate(birthDateField.getValue());
        driver.setDriversLicenceId(driversLicenceId.getText());
        userHib.updateUser(driver);

        FxUtils.alterMessage(Alert.AlertType.INFORMATION, "Successful", "User creation report", "User " + firstNameField.getText() + " updated successfully");

    }
    //Manager updatas
    private  void updateUserManager(Manager manager){
        manager.setUsername(usernameField.getText());
        manager.setPassword(passwordField.getText());
        manager.setName(firstNameField.getText());
        manager.setSurname(lastNameField.getText());
        manager.setEmail(emailField.getText());
        manager.setPhoneNumber(phoneNumberField.getText());
        manager.setAddress(addressField.getText());
        manager.setBirthDate(birthDateField.getValue());
        manager.setWorkEmail(workEmailField.getText());
        userHib.updateUser(manager);
    }


    public void createUser() {
        //Checks if text fields are empty
        if(firstNameField.getText().isEmpty() || lastNameField.getText().isEmpty() || usernameField.getText().isEmpty() || passwordField.getText().isEmpty())
        {
            FxUtils.alterMessage(Alert.AlertType.ERROR, "Error", "User creation report", "Some fields are empty");
        }
        else {
            if (managerChk.isSelected()) {
            Manager manager = new Manager(firstNameField.getText(), lastNameField.getText(), usernameField.getText(), passwordField.getText(), emailField.getText(), phoneNumberField.getText(), addressField.getText(), birthDateField.getValue(), workEmailField.getText());
            userHib.createUser(manager);
            } else {
            Driver driver = new Driver(firstNameField.getText(), lastNameField.getText(), usernameField.getText(), passwordField.getText(), emailField.getText(), phoneNumberField.getText(), addressField.getText(), birthDateField.getValue(), driversLicenceId.getText());
            userHib.createUser(driver);
            }
            FxUtils.alterMessage(Alert.AlertType.INFORMATION, "Successful", "User creation report", "User " + firstNameField.getText() + " created successfully");
        }

    }

    public void isManager() {
        if (managerChk.isSelected()){
            driversLicenceId.setDisable(true);
            workEmailField.setDisable(false);
        } else {
            workEmailField.setDisable(true);
            driversLicenceId.setDisable(false);
        }
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        isManager();
    }
}
