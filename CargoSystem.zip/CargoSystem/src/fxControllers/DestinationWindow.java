
package fxControllers;

import hibernate.CargoHib;
import hibernate.DestinationHib;
import hibernate.UserHib;
import hibernate.VehicleHib;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import model.Transport.Cargo;
import model.Transport.Destination;
import model.Transport.Vehicle;
import model.Users.Driver;
import model.Users.Manager;
import utils.FxUtils;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class DestinationWindow implements Initializable {
    @FXML
    public TextField DesStart;
    @FXML
    public TextField DesEnd;
    @FXML
    public Button actionButton;
    @FXML
    public ComboBox DesCargo; // Čia keiciau forma
    @FXML
    public ComboBox DesVehicle;
    @FXML
    public ComboBox DesDriver;
    @FXML
    public ComboBox DesManager;

    private Destination currentDestination;
    private Manager manager;

    private EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("CargoSystem");
    private DestinationHib destinationHib = new DestinationHib(entityManagerFactory);
    private CargoHib cargoHib = new CargoHib(entityManagerFactory);
    private VehicleHib vehicleHib = new VehicleHib(entityManagerFactory);
    private UserHib userHib = new UserHib(entityManagerFactory);

    public void setData(EntityManagerFactory entityManagerFactory, Destination currentDestination, Manager manager) {
        this.currentDestination = currentDestination;
        this.entityManagerFactory = entityManagerFactory;
        this.manager = manager;

        fillFields();

    }

    public void setManager(Manager manager) {
        this.manager = manager;
    }

    public void DisableData(int Propertie){
        switch(Propertie){
            case 1:{

                break;

            }
            case 2:{

                break;
            }
            case 3:{
                DesStart.setDisable(true);
                DesEnd.setDisable(true);
                DesManager.setDisable(true);
                DesCargo.setDisable(true);
                DesDriver.setDisable(true);
                break;
            }
            default:{}
        }
    }

    public void fillWindows() {
        List cargo = cargoHib.getAllCargo();
        DesCargo.getItems().addAll(cargo);

        List vehicle = vehicleHib.getAllVehicle();
        DesVehicle.getItems().addAll(vehicle);

        List driver = userHib.getAllDrivers();
        DesDriver.getItems().addAll(driver);

        List Managers = userHib.getAllManagers();
        DesManager.getItems().addAll(Managers);

    }

    public void disableCreateFields(){
        DesCargo.setDisable(true);
        DesVehicle.setDisable(true);
        DesDriver.setDisable(true);
        DesManager.setDisable(true);
    }

    private void fillFields() {
        Destination destination = destinationHib.getDestinationById(currentDestination.getId());
        DesStart.setText(destination.getStartPoint());
        DesEnd.setText(destination.getEndPoint());

        try{
            DesCargo.setValue(cargoHib.getCargoById(destination.getCargo().getId()));
        }
        catch (NullPointerException e){
            //Don't set value
        }
        try {
            DesVehicle.setValue(vehicleHib.getVehicleById(destination.getVehicle().getId()));
        }catch (NullPointerException e){
            //Ignore
        }
        try{
            DesDriver.setValue(userHib.getUserById(destination.getDriver().getId()));
        }catch (NullPointerException e){
            //Ignore
        }
        try {
            DesManager.setValue(userHib.getUserById(destination.getManager().getId()));
        }catch (NullPointerException e){
            //Ignore
        }
        actionButton.setOnAction(actionEvent ->{
            updateDestination(destination);
        });
        actionButton.setText("Update");

    }

    private void updateDestination (Destination destination) {
        destination.setStartPoint(DesStart.getText());
        destination.setEndPoint(DesEnd.getText());
        destination.setCargo((Cargo) DesCargo.getSelectionModel().getSelectedItem());
        destination.setVehicle((Vehicle) DesVehicle.getSelectionModel().getSelectedItem());
        destination.setDriver((Driver) DesDriver.getSelectionModel().getSelectedItem());
        destination.setManager((Manager) DesManager.getSelectionModel().getSelectedItem());

        destinationHib.updateDestination(destination);
        FxUtils.alterMessage(Alert.AlertType.INFORMATION, "Successful", "Destination update report", "Destination " +DesStart.getText()+ "-" +DesEnd.getText()+" updated successfully");
    }

    public void setData(EntityManagerFactory entityManagerFactory) {
        this.entityManagerFactory = entityManagerFactory;
        this.destinationHib = new DestinationHib(entityManagerFactory);
    }

    public void createDestination() {
        //Checks if text fields are empty
        if(DesStart.getText().isEmpty() || DesEnd.getText().isEmpty())
        {
            FxUtils.alterMessage(Alert.AlertType.ERROR, "Error", "Destination update report", "Some fields are empty");
        }
        else {
            Destination destination = new Destination(DesStart.getText(), DesEnd.getText(), manager);
            destinationHib.createDestination(destination);

            FxUtils.alterMessage(Alert.AlertType.INFORMATION, "Successful", "Destination update report", "Destination " +DesStart.getText()+ "-" +DesEnd.getText()+" created successfully");
        }

    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }


}