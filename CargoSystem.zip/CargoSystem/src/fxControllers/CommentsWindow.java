
package fxControllers;

import hibernate.CommentHib;
import hibernate.ForumHib;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import model.Forum.Comment;
import model.Forum.Forum;
import model.Users.User;
import utils.FxUtils;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class CommentsWindow implements Initializable {

    @FXML
    public ListView CommentList;

    @FXML
    public TextArea CommentText;

    @FXML
    public Button SendButton;

    private Forum currentForum;
    private User user;

    private EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("CargoSystem");
    private CommentHib commentHib = new CommentHib(entityManagerFactory);
    private ForumHib forumHib = new ForumHib(entityManagerFactory);


    public void setData(EntityManagerFactory entityManagerFactory, User user , Forum currentForum) {
        this.user = user;
        this.currentForum = currentForum;
        this.entityManagerFactory = entityManagerFactory;

        FillChat();
    }

    public void setData(EntityManagerFactory entityManagerFactory) {
        this.entityManagerFactory = entityManagerFactory;
    }

    void FillChat() {
        CommentList.getItems().clear();

        List<Comment> CommentsforForum = commentHib.getAllCommentsForForumID(currentForum.getId());
        CommentsforForum.forEach(b -> CommentList.getItems().add(b));

    }

    public void SendMessage() {
        //Checks if text fields are empty
        if(CommentText.getText().isEmpty())
        {
            FxUtils.alterMessage(Alert.AlertType.ERROR, "Error", "Chat report", "Enter message body!");
        }
        else {
            Comment comment = new Comment(user.getName() ,CommentText.getText(), currentForum);
            commentHib.createComment(comment);

            FxUtils.alterMessage(Alert.AlertType.INFORMATION, "Successful", "Forum creation report", "Forum created successfully");
            FillChat();
        }

    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }
}


