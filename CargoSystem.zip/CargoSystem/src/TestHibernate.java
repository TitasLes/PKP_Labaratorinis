import hibernate.UserHib;
import hibernate.VehicleHib;
import model.Transport.Vehicle;
import model.Users.Admin;
import model.Users.Driver;
import model.Users.Manager;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class TestHibernate {
    public static void main(String[] args) {
        EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("CargoSystem");
        UserHib userHib = new UserHib(entityManagerFactory);
        VehicleHib vehicleHib = new VehicleHib(entityManagerFactory);

        LocalDate HB = LocalDate.parse("2021-12-28", DateTimeFormatter.ofPattern("yyyy-MM-dd"));

        Admin admin = new Admin("Titas", "Lesnikauskas", "admin","admin","admin@gmail.com","867799420","Topoliu", HB ,Boolean.parseBoolean("True"));

        Driver driver1 = new Driver("Jonas","Jonavicius","driver1","driver1", "Jonas.Jonavicius@gmail.com", "864204452069", "Vilnius", HB, "45698852");
        Driver driver3 = new Driver("Tomas","Tomukevicius","driver3","driver3", "Tomas.Tomukevicius@gmail.com", "864241042069", "Vilnius", HB, "45566852");
        Driver driver2 = new Driver("Lukas","Lukevicius","driver2","driver2", "Lukas.Lukevicius@gmail.com", "864692042069", "Vilnius", HB, "45685442");

        Manager manager1 = new Manager("Monikue","Monik","manager1","manager1", "Monikue.Monik@gmail.com", "8674412254", "Vilnius", HB, "Monikue.Monik@cargo.com");

        userHib.createUser(admin);
        userHib.createUser(driver1);
        userHib.createUser(driver2);
        userHib.createUser(driver3);

        userHib.createUser(manager1);

        Vehicle car1 = new Vehicle("BWM", "330dx", "Labai kruta mašina", "225", "6.25");
        Vehicle car2 = new Vehicle("BWM", "T9", "Baisiai kruta mašina", "329", "6.65");
        Vehicle car3= new Vehicle("Man", "Euro 5", "Effektyvi mašina", "440", "5.25");

        vehicleHib.createVehicle(car1);
        vehicleHib.createVehicle(car2);
        vehicleHib.createVehicle(car3);
    }
}
