package model.Statuses;

public enum CargoStatus {
    NOT_STARTED ,SHIPPING, RESTING, COMPLETED;
}
