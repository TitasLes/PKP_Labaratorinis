package model.Statuses;

public enum Filters {
    Startpoint ,Endpoint, Cargo, Manager, Vehicle;
}
