package model.Users;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Entity;
import java.io.Serializable;
import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Admin extends User implements Serializable {

    private Boolean isAdmin;

    public Admin(String name, String surname, String username, String password, String email, String phoneNumber, String address, LocalDate birthDate, Boolean isAdmin) {
        super(name, surname, username, password, email, phoneNumber, address, birthDate);
        this.isAdmin = isAdmin;
    }

    public String ToString(){
        return getName() + " " + getSurname() + " " + getEmail();
    }

    public Boolean getAdmin() {
        return isAdmin;
    }

    public void setAdmin(Boolean admin) {
        isAdmin = admin;
    }
}


