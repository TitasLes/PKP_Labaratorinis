package model.Transport;

import lombok.Data;
import lombok.NoArgsConstructor;
import model.Statuses.CargoStatus;
import model.Users.Driver;
import model.Users.Manager;
import model.Users.User;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

@Data
@Entity
@NoArgsConstructor
public class Destination implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String startPoint;
    private String endPoint;


    @OneToOne
    private Cargo cargo;
    @ManyToOne
    private Vehicle vehicle;
    @ManyToOne
    private Driver driver;
    @OneToOne
    private Manager manager;

    public Destination(String startPoint, String endPoint, Manager manager) {
        this.startPoint = startPoint;
        this.endPoint = endPoint;
        this.manager = manager;
    }

    @Override
    public String toString(){
        return startPoint + " - " + endPoint;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getStartPoint() {
        return startPoint;
    }

    public void setStartPoint(String startPoint) {
        this.startPoint = startPoint;
    }

    public String getEndPoint() {
        return endPoint;
    }

    public void setEndPoint(String endPoint) {
        this.endPoint = endPoint;
    }





    public Cargo getCargo() {
        return cargo;
    }

    public void setCargo(Cargo cargo) {
        this.cargo = cargo;
    }

    public Vehicle getVehicle() {
        return vehicle;
    }

    public void setVehicle(Vehicle vehicle) {
        this.vehicle = vehicle;
    }

    public Driver getDriver() {
        return driver;
    }

    public void setDriver(Driver driver) {
        this.driver = driver;
    }

    public Manager getManager() {
        return manager;
    }

    public void setManager(Manager manager) {
        this.manager = manager;
    }
}
