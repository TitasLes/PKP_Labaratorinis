package model.Transport;

public enum destinationList {
    Alytus, Kaunas, Vilnius, Marijampole, Klaipeda
}
