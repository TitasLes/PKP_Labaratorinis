package hibernate;

import model.Transport.Cargo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;

public class CargoHib {
    EntityManager entityManager = null;
    EntityManagerFactory entityManagerFactory = null;

    public CargoHib(EntityManagerFactory entityManagerFactory) {
        this.entityManagerFactory = entityManagerFactory;
    }

    public void createCargo(Cargo cargo) {
        entityManager = entityManagerFactory.createEntityManager();
        try {
            entityManager.getTransaction().begin();
            entityManager.persist(cargo);
            entityManager.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (entityManager != null) entityManager.close();
        }
    }

    public void updateCargo(Cargo cargo) {
        entityManager = entityManagerFactory.createEntityManager();
        try {
            entityManager.getTransaction().begin();
            entityManager.merge(cargo);
            entityManager.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (entityManager != null) entityManager.close();
        }
    }

    public void deleteCargo(Cargo cargo) {
        entityManager = entityManagerFactory.createEntityManager();
        try {
            entityManager.getTransaction().begin();
            entityManager.remove(entityManager.find(Cargo.class, cargo.getId()));
            entityManager.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (entityManager != null) entityManager.close();
        }
    }

    public List<Cargo> getAllCargo() {
        entityManager = entityManagerFactory.createEntityManager();
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Cargo> query = criteriaBuilder.createQuery(Cargo.class);
        Root<Cargo> root = query.from(Cargo.class);
        query.select(root);
        Query q;
        try {
            q = entityManager.createQuery(query);
            return q.getResultList();
        } catch (NoResultException e) {
            return new ArrayList<>();
        }

    }

    public Cargo getCargoById(int id) {
        entityManager = entityManagerFactory.createEntityManager();
        Cargo cargo = null;
        try {
            entityManager.getTransaction().begin();
            cargo = entityManager.find(Cargo.class, id);
            entityManager.getTransaction().commit();
        } catch (Exception e) {
            System.out.println("No such cargo by given id");
        }
        return cargo;
    }
}
